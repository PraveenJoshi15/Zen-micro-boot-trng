package com.microservices.service1.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ServiceApplicationController {
	
	
	@Value("${server.instance.name}")
	private String instanceName;
	
	@GetMapping
	public String sayMicroservices() {
		return "<h1> Hello From " + instanceName + "</h1>";
	}

}
