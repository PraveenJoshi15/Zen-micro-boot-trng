package com.microclient.client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
//import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import com.netflix.discovery.EurekaClient;

@SpringBootApplication
@EnableEurekaClient

// Difference between eureka client and discovery client is that eureka client depends on third party dependencies
//@EnableDiscoveryClient
public class ClientApplication {
	

	public static void main(String[] args) {
		SpringApplication.run(ClientApplication.class, args);
	}

}
