package com.zensar.goodByeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoodByeServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
