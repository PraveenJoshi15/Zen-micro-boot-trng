package com.zensar.goodByeservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GoodByeServiceController {
	
	
	@GetMapping
	public String sayGoodBye() {
		return "<h1>good-Bye </h1>";
	}

}
