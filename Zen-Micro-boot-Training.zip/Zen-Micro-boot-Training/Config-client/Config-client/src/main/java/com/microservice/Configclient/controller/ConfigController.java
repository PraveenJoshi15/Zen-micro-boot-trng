package com.microservice.Configclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.Configclient.ConfigClientPropertiesDemo;

@RestController
@RefreshScope //is used to make @value property get fetched updated value when value getting changed inside repository
//hit https://localhost:9080/actuator/refresh to get the update value from repository
public class ConfigController {
	
	@Autowired
	private ConfigClientPropertiesDemo demoProperty;
	
	// @value follows Eager - fetching
	@Value("${some.property}")
	private String propertyValue;
	
	@GetMapping
	public String getPropertyValue() {
		
		StringBuilder sb = new StringBuilder();
		sb.append(demoProperty.getProperty());
		
		sb.append(" || ");
		
		sb.append(propertyValue);
		
		return sb.toString();
	}

}
