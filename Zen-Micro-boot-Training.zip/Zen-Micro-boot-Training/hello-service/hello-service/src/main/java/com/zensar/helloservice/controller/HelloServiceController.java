package com.zensar.helloservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloServiceController {
	
	
	@GetMapping
	public String sayHello(@RequestHeader("x-location") String location) {
		
		return "<h1> hello from " + location + "</h1>";
	}

}
