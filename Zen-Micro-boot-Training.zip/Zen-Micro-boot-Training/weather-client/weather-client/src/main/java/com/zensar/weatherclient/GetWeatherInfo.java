package com.zensar.weatherclient;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class GetWeatherInfo {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@HystrixCommand(fallbackMethod = "unknown")
	public String getWeather() {

		return restTemplate.getForEntity("http://localhost:4444/current/weather", String.class).getBody(); 
	}
	
	public String unknown() {
		
		return "<h1> Weather service down </h1>";
	}

}
