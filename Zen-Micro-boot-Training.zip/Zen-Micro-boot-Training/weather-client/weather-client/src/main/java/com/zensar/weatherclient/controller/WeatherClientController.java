package com.zensar.weatherclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.zensar.weatherclient.GetWeatherInfo;

@RestController
public class WeatherClientController {
	
	@Autowired
	private GetWeatherInfo info;
	
	@GetMapping
	public String getWeather() {
		return "Today's weather" + info.getWeather();
	}

}
